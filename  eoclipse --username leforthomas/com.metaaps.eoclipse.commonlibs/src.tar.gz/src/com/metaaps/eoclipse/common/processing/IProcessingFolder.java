package com.metaaps.eoclipse.common.processing;

/**
 * @author leforthomas
 */
public interface IProcessingFolder {

}

package com.metaaps.eoclipse.common.processing;

import java.util.HashMap;

import com.metaaps.eoclipse.common.IData;
import com.metaaps.eoclipse.common.IDataContent;

/**
 * @author leforthomas
 */
public interface IProcessing {

	IDataContent execute();

	void setParameters(HashMap<String, Object> parameters);
	
	HashMap<String, Object> getParameters();

}

package com.metaaps.eoclipse.common;

import java.io.Serializable;

/**
 * @author leforthomas
 */
public interface IModel extends IDescriptor, ISerialize {
	
	public void addListener(IModelChangeListener listener);
	
	public void removeListener(IModelChangeListener listener);
	
	public void addChild(Object obj);
	
	public Object[] getChildren();
	
	public void removeChild(Object obj);
	
	public void setParent(Object obj);
	
	public Object getParent();
}

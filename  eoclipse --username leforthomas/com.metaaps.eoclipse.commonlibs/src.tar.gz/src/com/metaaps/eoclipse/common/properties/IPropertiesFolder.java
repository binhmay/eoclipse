package com.metaaps.eoclipse.common.properties;

public interface IPropertiesFolder {

}

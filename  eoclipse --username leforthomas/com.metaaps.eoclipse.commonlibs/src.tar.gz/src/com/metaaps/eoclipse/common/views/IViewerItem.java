package com.metaaps.eoclipse.common.views;

public interface IViewerItem {

}

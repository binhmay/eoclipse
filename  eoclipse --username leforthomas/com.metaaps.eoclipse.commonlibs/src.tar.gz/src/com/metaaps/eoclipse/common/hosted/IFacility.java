package com.metaaps.eoclipse.common.hosted;

import com.metaaps.eoclipse.common.IWorkFlow;

public interface IFacility {

	public void host(IWorkFlow workflow);

}

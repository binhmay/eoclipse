package com.metaaps.eoclipse.common;

import java.util.HashMap;

public interface IDataContent {
	
	public static String IMAGE = "Image"; 
	public static String VECTOR = "Vector";
	
	// redundant with the plugins extension attribute Type
	// TBC if necessary
	public String getType();
	public void setType(String type);
	// code specifying how the data content was generated
	public CodeFragment getCode();
	public void setCode(CodeFragment codeFragment);
	// format of the data
	public String getDataFormat();
	public void setDataFormat(String format);
	// name, description and properties of data
	public String getName();
	public String getDescription();
	public HashMap<String, Object> getProperties();

}

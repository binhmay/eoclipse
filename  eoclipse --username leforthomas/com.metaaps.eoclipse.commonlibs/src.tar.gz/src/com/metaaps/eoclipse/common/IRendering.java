package com.metaaps.eoclipse.common;

/**
 * @author leforthomas
 */
public interface IRendering {
	
	public String getActionText();

}

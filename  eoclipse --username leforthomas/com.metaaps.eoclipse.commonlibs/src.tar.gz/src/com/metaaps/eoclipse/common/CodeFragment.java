package com.metaaps.eoclipse.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;

public class CodeFragment implements ISerialize {
	
	public static String SOURCE = "source";
	public static String GENERATED = "generated";
	private String m_type;
	private int m_dataid;
	private HashMap<String, Object> m_properties;
	
	public CodeFragment(String type, int dataid, HashMap<String, Object> properties) {
		m_type = type;
		m_dataid = dataid;
		m_properties = properties;
	}
	
	public String getType() {
		return m_type;
	}
	
	public Object getProperty(String key) {
		return (m_properties == null ? null : m_properties.get(key));
	}

	public Iterator<String> getPropertyIterator() {
		return (m_properties == null ? null : m_properties.keySet().iterator());
	}

	@Override
	public void writeToStream(OutputStream stream) throws IOException {
		// TODO Auto-generated method stub
		Iterator<String> properties = getPropertyIterator();
		while(properties.hasNext()) {
			String property = properties.next();
			Object value = getProperty(property);
			stream.write(new String("<" + property + ">" + value.toString() + "</" + property + ">").getBytes());
		}
	}

	@Override
	public void readFromStream(InputStream stream) {
		// TODO Auto-generated method stub
		
	}

}

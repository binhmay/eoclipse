package com.metaaps.eoclipse.common;

import org.eclipse.jface.resource.ImageDescriptor;

/**
 * @author leforthomas
 */
public interface IDescriptor {

	String getLabel();

	ImageDescriptor getImageDescriptor();

	String getId();
}

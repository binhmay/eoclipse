package com.metaaps.eoclipse.common;

import java.util.HashMap;

import org.eclipse.core.expressions.EvaluationResult;
import org.eclipse.core.expressions.Expression;
import org.eclipse.core.expressions.IEvaluationContext;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.menus.AbstractContributionFactory;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;
import org.eclipse.ui.menus.IContributionRoot;
import org.eclipse.ui.menus.IMenuService;
import org.eclipse.ui.services.IServiceLocator;

/**
 * @author leforthomas
 */
public class Util {

	public static Object searchForInterface(Class clazz, Object[] objects){
		if(objects == null)
		{
			return null;
		}
		for(int i = 0; i < objects.length; i++)
		{
			if(clazz.isInstance(objects[i]))
			{
				return objects[i];
			}
		}
		return null;
	}
	
	public static Object scanTree(Class clazz, Object item)
	{
		if(item instanceof Model)
		{
			if(clazz.isInstance(item))
			{
				return item;
			} else {
				if(((Model)item).getParent() != null)
				{
					return scanTree(clazz, ((Model)item).getParent());
				} else {
					return null;
				}
			}
		}
		
		return null;
	}
	
	public static Object scanTreePath(ITreeSelection selection, Class clazz) {
        TreePath[] treepaths = selection.getPaths();
        TreePath path = treepaths[0];
        for(int i = 0; i < path.getSegmentCount(); i++) {
        	Object obj = path.getSegment(i);
        	if(clazz.isInstance(obj)) {
        		return obj;
        	}
        }
        
        return null;
	}
	
	public static Object getAttributeFromExtension(String extensionid, String pointname, String attributename) {
		IExtensionPoint processing = Platform.getExtensionRegistry().getExtensionPoint(extensionid);
		IExtension[] extensions = processing.getExtensions();
		for (IExtension extension : extensions) {
			IConfigurationElement[] elements =
	            extension.getConfigurationElements();
			for(IConfigurationElement element : elements)
			{
				if(element.getName().contentEquals(pointname))
				{
					return element.getAttribute(attributename);
				}
			}
		}
		return null;
	}
	
	public static void addPopupMenu(String popupmenuid, String pluginid, String menulabel, String menuid, String commandid, Class triggerClazz, HashMap<String, String> parameters) {
		IMenuService service = (IMenuService) PlatformUI.getWorkbench().getService(IMenuService.class);
		final HashMap<String, String> fparameters = parameters;
	    final String fmenulabel = menulabel;
		final String fcommandid = commandid;
		final String fmenuid = menuid;
		final Class ftriggerClazz = triggerClazz;

		AbstractContributionFactory menucontribution =
			   new AbstractContributionFactory(popupmenuid, pluginid) {
			

				@Override
				public void createContributionItems(IServiceLocator serviceLocator,
						IContributionRoot additions) {
					
					CommandContributionItemParameter contributionParameters = 
				    	new CommandContributionItemParameter(serviceLocator, fmenuid, fcommandid, 
				    			null, null, null, null, fmenulabel, null, null, 
				    			CommandContributionItem.STYLE_PUSH, null, false);
				    
					CommandContributionItem item = new CommandContributionItem(contributionParameters );
					item.setVisible(true);
					additions.addContributionItem(item, new Expression() {
						
						@Override
						public EvaluationResult evaluate(IEvaluationContext context)
								throws CoreException {
							boolean isdatasets = false;
							Object obj = context.getVariable("selection");
							if(obj instanceof IStructuredSelection) {
								IStructuredSelection selection = (IStructuredSelection) obj;
								if(ftriggerClazz.isInstance(selection.getFirstElement()))
								{
									isdatasets = true;
								}
							}
							return EvaluationResult.valueOf(isdatasets);
						}
					});
				}
		};
		
		service.addContributionFactory(menucontribution);
	}
	
}

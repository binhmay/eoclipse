package com.metaaps.eoclipse.common;

import org.eclipse.jface.resource.ImageDescriptor;

/**
 * @author leforthomas
 */
public interface ITools {

	String getLabel();

	ImageDescriptor getImageDescriptor();

	String getId();
}

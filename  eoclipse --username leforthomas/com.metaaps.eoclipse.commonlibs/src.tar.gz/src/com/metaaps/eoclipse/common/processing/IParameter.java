package com.metaaps.eoclipse.common.processing;

import java.util.ArrayList;

public interface IParameter {
	
	String getName();
	
	ArrayList<String> getSupportedTypes();

}

package com.metaaps.eoclipse.common;

public abstract class DataContent implements IDataContent {

	private String m_type = "";
	private CodeFragment m_code = null;
	private String m_format = "";

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return m_type;
	}

	@Override
	public void setType(String type) {
		// TODO Auto-generated method stub
		if(type != null)
		{
			m_type = type;
		}

	}

	@Override
	public CodeFragment getCode() {
		// TODO Auto-generated method stub
		return m_code;
	}

	@Override
	public void setCode(CodeFragment code) {
		// TODO Auto-generated method stub
		if(code != null)
		{
			m_code = code;
		}

	}
	
	@Override
	public String getDataFormat() {
		// TODO Auto-generated method stub
		return m_format;
	}
	
	@Override
	public void setDataFormat(String format) {
		if(format != null)
		{
			m_format = format;
		}
	}

}

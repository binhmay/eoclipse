package com.metaaps.eoclipse.common;

import org.eclipse.jface.resource.ImageDescriptor;

/**
 * @author leforthomas
 */
public class Property extends Model {
	
	private Object m_value;
	private String m_property;

	public Property(String property, Object value)
	{
		m_property = property;
		m_value = value;
	}
	
	public Object getValue() {
		return m_value;
	}
	
	public String getProperty() {
		return m_property;
	}

	@Override
	public String getLabel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ImageDescriptor getImageDescriptor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}
	
}

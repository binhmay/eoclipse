package com.metaaps.eoclipse.common.processing;

import java.util.HashMap;

import com.metaaps.eoclipse.common.IDataContent;

public class AbstractProcessing implements IProcessing {

	private HashMap<String, Object> m_parameters;

	@Override
	public IDataContent execute() {
		// TODO Auto-generated method stub
		System.out.println("Execute Method of Processing element not implemented");
		return null;
	}

	@Override
	public void setParameters(HashMap<String, Object> parameters) {
		m_parameters = parameters;
	}

	@Override
	public HashMap<String, Object> getParameters() {
		// TODO Auto-generated method stub
		return m_parameters;
	}

}

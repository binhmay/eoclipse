package com.metaaps.eoclipse.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * @author leforthomas
 */
public abstract class Model implements IModel {
	
	public static final String REMOVED = "REMOVED";
	public static final String ADDED = "ADDED";

	protected IModelChangeListener listener = NullDeltaListener.getSoleInstance();
	
	protected ArrayList<Object> m_children = new ArrayList<Object>();
	
	protected Object m_parent = null;
	
	public void fireChanged(Object added, String event) {
		listener.modelChanged(added, event);
	}

	public void addListener(IModelChangeListener listener) {
		this.listener = listener;
	}
	
	public void removeListener(IModelChangeListener listener) {
		if(this.listener.equals(listener)) {
			this.listener = NullDeltaListener.getSoleInstance();
		}
	}
	
	@Override
	public void addChild(Object obj) {
		// TODO Auto-generated method stub
		m_children.add(obj);
		if(obj instanceof Model)
		{
			((Model)obj).setParent(this);
		}
//		fireChanged(obj, Model.ADDED);
	}
	
	@Override
	public Object[] getChildren() {
		// TODO Auto-generated method stub
		return m_children.toArray();
	}
	
	@Override
	public void removeChild(Object obj) {
		// TODO Auto-generated method stub
		m_children.remove(obj);
//		fireChanged(obj, Model.REMOVED);
	}
	
	@Override
	public void setParent(Object obj) {
		// TODO Auto-generated method stub
		m_parent = obj;
	}
	
	@Override
	public Object getParent() {
		// TODO Auto-generated method stub
		return m_parent;
	}
	
	@Override
	public void readFromStream(InputStream stream) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void writeToStream(OutputStream stream) throws IOException {
		// TODO Auto-generated method stub
		
	}

}

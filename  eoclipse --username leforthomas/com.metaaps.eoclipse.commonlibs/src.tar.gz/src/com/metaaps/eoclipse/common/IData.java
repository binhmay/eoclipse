package com.metaaps.eoclipse.common;

/**
 * @author leforthomas
 */
public interface IData extends IModel {

	IDataContent getDataContent();
}

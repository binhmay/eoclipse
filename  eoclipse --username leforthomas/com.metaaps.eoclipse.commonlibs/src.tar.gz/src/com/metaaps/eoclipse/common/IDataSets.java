package com.metaaps.eoclipse.common;

/**
 * @author leforthomas
 */
public interface IDataSets extends IModel {

	void addDataContent(IDataContent data);

}

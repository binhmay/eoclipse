package com.metaaps.eoclipse.common.views;

import com.metaaps.eoclipse.common.IModelChangeListener;
import com.metaaps.eoclipse.common.IWorkFlow;

public interface IViewer extends IModelChangeListener {

	void open(IWorkFlow workflow);

}

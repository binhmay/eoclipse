package com.metaaps.eoclipse.common;

public class NullDeltaListener implements IModelChangeListener {
	protected static NullDeltaListener soleInstance = new NullDeltaListener();
	public static NullDeltaListener getSoleInstance() {
		return soleInstance;
	}
	
	@Override
	public void modelChanged(Object element, String event) {
		// TODO Auto-generated method stub
		
	}
	
}

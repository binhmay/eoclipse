package com.metaaps.eoclipse.common.datasets;

import com.metaaps.eoclipse.common.IDataSets;

public interface IImportMethod {

	void insertData(IDataSets datasets);

}

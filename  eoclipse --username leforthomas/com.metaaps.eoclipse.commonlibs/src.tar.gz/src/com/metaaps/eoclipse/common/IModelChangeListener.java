package com.metaaps.eoclipse.common;

/**
 * @author leforthomas
 */
public interface IModelChangeListener {
	public void modelChanged(Object element, String event);
}

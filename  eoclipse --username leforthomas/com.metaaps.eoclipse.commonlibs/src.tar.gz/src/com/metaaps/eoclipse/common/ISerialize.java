package com.metaaps.eoclipse.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface ISerialize {
	
	public void writeToStream(OutputStream stream) throws IOException;
	public void readFromStream(InputStream stream);

}

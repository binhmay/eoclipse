package com.metaaps.eoclipse.common.hosted;

public interface IFacilityItem {

}

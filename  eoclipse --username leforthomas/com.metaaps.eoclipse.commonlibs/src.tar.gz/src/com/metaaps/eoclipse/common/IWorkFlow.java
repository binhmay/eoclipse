package com.metaaps.eoclipse.common;

/**
 * @author leforthomas
 */
public interface IWorkFlow extends IModel {

}

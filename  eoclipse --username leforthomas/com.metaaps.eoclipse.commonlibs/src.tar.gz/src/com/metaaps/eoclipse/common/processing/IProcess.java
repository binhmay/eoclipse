package com.metaaps.eoclipse.common.processing;

import com.metaaps.eoclipse.common.IData;
import com.metaaps.eoclipse.common.IModel;

/**
 * @author leforthomas
 */
public interface IProcess extends IModel {

	void execute(IData data);

}
